<?php
// Production Database connection using PDO
function connectDB() {
    // Update these values with your hosting provider's database details
    $host = 'localhost'; // Usually 'localhost' for shared hosting
    $dbname = 'your_database_name'; // Replace with your actual database name
    $username = 'your_db_username'; // Replace with your database username
    $password = 'your_db_password'; // Replace with your database password
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        
        // Set PDO to throw exceptions on error
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Use prepared statements by default
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        
        // Set default fetch mode
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        
        return $pdo;
    } catch (PDOException $e) {
        // Log the error but don't display it to users in production
        error_log("Database connection failed: " . $e->getMessage());
        die("Database connection failed. Please try again later.");
    }
}

// Production settings
ini_set('display_errors', 0); // Hide errors from users in production
ini_set('log_errors', 1); // Log errors to file
error_reporting(E_ALL); // Report all errors to log

// Security settings
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);

// Only enable secure cookies if using HTTPS
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
?>
